import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# ----------------------------
# Load Dataset
# ----------------------------
df = pd.read_csv("Titanic-Dataset.csv")

# Select useful columns
df = df[[
    "Pclass",
    "Sex",
    "Age",
    "SibSp",
    "Parch",
    "Fare",
    "Embarked",
    "Survived"
]]

# ----------------------------
# Handle Missing Values
# ----------------------------
df["Age"] = df["Age"].fillna(df["Age"].median())
df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

# ----------------------------
# Manual Encoding
# ----------------------------

# Sex
df["Sex"] = df["Sex"].map({
    "female": 0,
    "male": 1
})

# Embarked
df["Embarked"] = df["Embarked"].map({
    "C": 0,
    "Q": 1,
    "S": 2
})

# ----------------------------
# Features & Target
# ----------------------------
X = df.drop("Survived", axis=1)
y = df["Survived"]

# ----------------------------
# Split Data
# ----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# ----------------------------
# Train Model
# ----------------------------
model = DecisionTreeClassifier(
    random_state=42,
    max_depth=4
)

model.fit(X_train, y_train)

# ----------------------------
# Accuracy
# ----------------------------
predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)

print("Accuracy :", accuracy)

# ----------------------------
# Save Model
# ----------------------------
joblib.dump(model, "model.pkl")

print("Model Saved Successfully!")