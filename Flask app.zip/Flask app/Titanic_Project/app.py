from flask import Flask, render_template, request
import joblib

app = Flask(__name__)

model = joblib.load("model.pkl")


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():

    pclass = int(request.form["Pclass"])

    sex = request.form["Sex"]

    if sex == "female":
        sex = 0
    else:
        sex = 1

    age = float(request.form["Age"])

    sibsp = int(request.form["SibSp"])

    parch = int(request.form["Parch"])

    fare = float(request.form["Fare"])

    embarked = request.form["Embarked"]

    if embarked == "C":
        embarked = 0
    elif embarked == "Q":
        embarked = 1
    else:
        embarked = 2

    data = [[
        pclass,
        sex,
        age,
        sibsp,
        parch,
        fare,
        embarked
    ]]

    prediction = model.predict(data)

    if prediction[0] == 1:
        result = "✅ Passenger Survived"
    else:
        result = "❌ Passenger Did Not Survive"

    return render_template(
        "index.html",
        prediction=result
    )


if __name__ == "__main__":
    app.run(debug=True)